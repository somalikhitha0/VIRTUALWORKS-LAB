from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# Create DB + Table
def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS coffee (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            votes INTEGER
        )
    ''')

    # Default data insert (only first time)
    c.execute("SELECT COUNT(*) FROM coffee")
    if c.fetchone()[0] == 0:
        coffees = [
            ("Ethiopian Yirgacheffe", 125),
            ("Sumatra Mandheling", 150),
            ("Cold Brew Nitro", 120),
            ("Vanilla Latte", 125)
        ]
        c.executemany("INSERT INTO coffee (name, votes) VALUES (?, ?)", coffees)

    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT * FROM coffee")
    data = c.fetchall()
    conn.close()
    return render_template('index.html', coffees=data)

@app.route('/vote/<int:id>')
def vote(id):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("UPDATE coffee SET votes = votes + 1 WHERE id=?", (id,))
    conn.commit()
    conn.close()
    return redirect('/')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)