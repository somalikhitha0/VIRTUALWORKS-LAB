document.getElementById("profileForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const bio = document.getElementById("bio").value;
    const image = document.getElementById("image").value;

    try {
        const response = await fetch("http://localhost:5000/create-profile", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ name, bio, image })
        });

        const data = await response.json();

        document.getElementById("cardContainer").innerHTML = `
            <div class="card">
                <img src="${data.image}" />
                <h3>${data.name}</h3>
                <p>${data.bio}</p>
            </div>
        `;
    } catch (error) {
        alert("Backend not running!");
    }
});