const express = require("express");
const cors = require("cors");

const app = express();

// middleware
app.use(cors());
app.use(express.json());

// test route
app.get("/", (req, res) => {
    res.send("Backend is working 🚀");
});

// POST route
app.post("/create-profile", (req, res) => {
    const { name, bio, image } = req.body;

    if (!name || !bio || !image) {
        return res.status(400).json({ error: "All fields required" });
    }

    res.json({
        name,
        bio,
        image
    });
});

// server start
app.listen(5000, () => {
    console.log("✅ Server running at http://localhost:5000");
});